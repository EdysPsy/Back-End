import './App.css';

import './App.css';

function App() {
  const name = 'Edson';
  const newName = name.toUpperCase()
  const url = "https://corhexa.com/png/600x400/2s4fc2";

  function sum(a, b) {
    return a + b;
  }

  return (
    <div className="App">

      <h1>Olá REACT</h1>
      <p>Olá, {newName}!</p> 
      <p>Esse é meu primeiro APP...</p>
      <p>O resultado de 1 + 2 é : {sum(1, 2)}</p>
      <img src={url} alt="Minha Imagem" />
    </div>
  
  );
}

export default App;
